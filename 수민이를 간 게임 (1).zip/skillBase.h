#pragma once
class skillBase
{
public:
	skillBase();
	~skillBase();
};

