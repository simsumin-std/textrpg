#include "skillBase.h"



skillBase::skillBase()
{
}


skillBase::~skillBase()
{
}
