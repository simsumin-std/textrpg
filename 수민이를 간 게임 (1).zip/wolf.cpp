#include "wolf.h"



wolf::wolf()
{
	SetAtk(3);
	SetExp(15);
	SetGold(30);
	SetHp(33);
	SetFullHp(33);
	SetName("����");
}


wolf::~wolf()
{
}
