#include "magicArmor.h"



magicArmor::magicArmor()
{
	_name = "�⺻����";
	price = 500;
	count = 0;
	option = 15;
	get = false;
}


magicArmor::~magicArmor()
{
}
