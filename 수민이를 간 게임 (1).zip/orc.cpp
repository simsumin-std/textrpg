#include "orc.h"



orc::orc()
{
	SetAtk(12);
	SetExp(100);
	SetGold(100);
	SetHp(333);
	SetFullHp(333);
	SetName("��ũ");
}


orc::~orc()
{
}
