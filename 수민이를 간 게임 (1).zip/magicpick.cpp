#include "magicpick.h"



magicpick::magicpick()
{
	_name = "�������";
	price = 500;
	count = 0;
	option = 50;
	get = false;
}


magicpick::~magicpick()
{
}
