#include "gold.h"



gold::gold()
{
	_name = "�ݱ���";
	price = 30;
	count = 0;
	option = 30;
}


gold::~gold()
{
}
