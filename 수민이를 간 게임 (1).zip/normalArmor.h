#pragma once
#include "item.h"
class normalArmor :
	public item
{
public:
	normalArmor();
	~normalArmor();
};

