#include "goldenArmor.h"



goldenArmor::goldenArmor()
{
	_name = "��������";
	price = 1000;
	count = 0;
	option = 50;
	get = false;
}


goldenArmor::~goldenArmor()
{
}
