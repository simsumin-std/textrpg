#pragma once
#include "item.h"
class normalhoe :
	public item
{
public:
	normalhoe();
	~normalhoe();
};

