#pragma once
#include "item.h"
class magicArmor :
	public item
{
public:
	magicArmor();
	~magicArmor();
};

