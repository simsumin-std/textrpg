#pragma once
#include "item.h"
class normalSword :
	public item
{
public:
	normalSword();
	~normalSword();
};

