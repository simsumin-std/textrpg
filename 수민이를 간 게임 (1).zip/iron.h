#pragma once
#include "item.h"
class iron :
	public item
{
public:
	iron();
	~iron();
};

