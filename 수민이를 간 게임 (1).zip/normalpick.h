#pragma once
#include "item.h"
class normalpick :
	public item
{
public:
	normalpick();
	~normalpick();
};

