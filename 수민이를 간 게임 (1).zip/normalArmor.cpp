#include "normalArmor.h"



normalArmor::normalArmor()
{
	_name = "����";
	price = 50;
	count = 0;
	option = 5;
	get = false;
}


normalArmor::~normalArmor()
{
}
