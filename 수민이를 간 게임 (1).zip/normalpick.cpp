#include "normalpick.h"



normalpick::normalpick()
{
	_name = "�⺻���";
	price = 50;
	count = 0;
	option = 5;
	get = false;
}


normalpick::~normalpick()
{
}
