#include "normalSword.h"




normalSword::normalSword()
{
	_name = "�⺻ ��";
	price = 50;
	count = 0;
	option = 5;
	get = false;
}


normalSword::~normalSword()
{
}
