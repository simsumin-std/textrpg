#pragma once
#include "monster.h"
class orc :
	public monster
{
public:
	orc();
	~orc();
};

