#pragma once
#include "item.h"
class goldenArmor :
	public item
{
public:
	goldenArmor();
	~goldenArmor();
};

