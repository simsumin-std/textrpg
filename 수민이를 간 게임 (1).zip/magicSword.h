#pragma once
#include "item.h"
class magicSword :
	public item
{
public:
	magicSword();
	~magicSword();
};

