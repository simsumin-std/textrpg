#pragma once
#include "item.h"
class goldenSword :
	public item
{
public:
	goldenSword();
	~goldenSword();
};

