#include "fireSword.h"



fireSword::fireSword()
{
	_name = "���� ��";
	price = 500;
	count = 0;
	option = 50;
	get = false;
}


fireSword::~fireSword()
{
}
