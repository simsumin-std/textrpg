#include "magicSword.h"



magicSword::magicSword()
{
	_name = "������";
	price = 200;
	count = 0;
	option = 15;
	get = false;
}


magicSword::~magicSword()
{
}
