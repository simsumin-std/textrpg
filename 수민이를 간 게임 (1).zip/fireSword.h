#pragma once
#include "item.h"
class fireSword :
	public item
{
public:
	fireSword();
	~fireSword();
};

