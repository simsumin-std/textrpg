#pragma once
#include "monster.h"
class wolf :
	public monster
{
public:
	wolf();
	~wolf();
};

