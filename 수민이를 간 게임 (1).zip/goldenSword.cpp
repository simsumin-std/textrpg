#include "goldenSword.h"



goldenSword::goldenSword()
{
	_name = "Ȳ�ݰ�";
	price = 1200;
	count = 0;
	option = 100;
	get = false;
}


goldenSword::~goldenSword()
{
}
