#pragma once
#include "monster.h"
class goblin :
	public monster
{
public:
	goblin();
	~goblin();
};

