#include "iron.h"



iron::iron()
{
	_name = "ö����";
	price = 10;
	count = 0;
	option = 10;
}


iron::~iron()
{
}
