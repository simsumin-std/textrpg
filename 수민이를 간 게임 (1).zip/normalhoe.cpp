#include "normalhoe.h"



normalhoe::normalhoe()
{
	_name = "�⺻����";
	price = 50;
	count = 0;
	option = 5;
	get = false;
}


normalhoe::~normalhoe()
{
}
