#include "goblin.h"



goblin::goblin()
{
	SetAtk(2);
	SetExp(5);
	SetGold(10);
	SetHp(11);
	SetFullHp(11);
	SetName("������");
}


goblin::~goblin()
{
}
