#pragma once
#include "item.h"
class magicpick :
	public item
{
public:
	magicpick();
	~magicpick();
};

