#pragma once
#include "item.h"
class gold :
	public item
{
public:
	gold();
	~gold();
};

